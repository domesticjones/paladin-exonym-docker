<?php get_header(); ?>

<div>
  <h1>hello world!</h1>
</div>

<?php get_footer(); ?>
